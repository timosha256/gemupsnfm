export default {
    gemupsData: {
        user: {
            isAuth: false,
            credentials: {
                username: "",
                email: "",
                password: ""
            }
        },
        
    }
}