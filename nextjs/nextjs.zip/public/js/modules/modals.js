const myModal = new HystModal({
    linkAttributeName: "data-hystmodal",
});